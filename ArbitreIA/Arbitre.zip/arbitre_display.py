import pygame
import sys
from arbitreV5 import ServeurArbitre
import threading
import queue
import math
import tkinter as tk
from tkinter import simpledialog

class AmongUsPlayer:
    def __init__(self, color, x, y, scale=1.0):
        self.color = color
        self.x = x
        self.y = y
        self.scale = scale
        self.animation_offset = 0
        
    def draw(self, screen, is_spy=False, is_dead=False):
        s = self.scale
        # Corps principal
        pygame.draw.ellipse(screen, self.color, 
                          (self.x - 20*s, self.y - 30*s + math.sin(self.animation_offset)*3, 
                           40*s, 50*s))
        # Jambes
        pygame.draw.ellipse(screen, self.color, 
                          (self.x - 20*s, self.y + 10*s, 15*s, 25*s))
        pygame.draw.ellipse(screen, self.color, 
                          (self.x + 5*s, self.y + 10*s, 15*s, 25*s))
        # Vitre du casque
        pygame.draw.ellipse(screen, (174, 218, 255), 
                          (self.x - 10*s, self.y - 25*s, 25*s, 15*s))
        
        if is_dead:
            # X rouge pour les joueurs éliminés
            pygame.draw.line(screen, (255, 0, 0), 
                           (self.x - 15*s, self.y - 15*s), 
                           (self.x + 15*s, self.y + 15*s), 3)
            pygame.draw.line(screen, (255, 0, 0), 
                           (self.x - 15*s, self.y + 15*s), 
                           (self.x + 15*s, self.y - 15*s), 3)
        
        if is_spy:
            # Couteau pour l'imposteur
            knife_points = [
                (self.x + 25*s, self.y),
                (self.x + 35*s, self.y - 5*s),
                (self.x + 40*s, self.y),
                (self.x + 35*s, self.y + 5*s)
            ]
            pygame.draw.polygon(screen, (169, 169, 169), knife_points)

class ArbitreDisplay:
    def __init__(self, broker_ip):
        # Configuration initiale de Pygame et de la fenêtre
        pygame.init()
        
        # Demande du nombre de joueurs
        root = tk.Tk()
        root.withdraw()
        nb_joueurs = simpledialog.askinteger("Configuration", 
                                           "Nombre de joueurs (2-10):", 
                                           minvalue=2, maxvalue=10)
        if nb_joueurs is None:
            sys.exit()

        # Configuration de la fenêtre
        self.WIDTH = 1280
        self.HEIGHT = 800
        self.screen = pygame.display.set_mode((self.WIDTH, self.HEIGHT))
        pygame.display.set_caption("Among Us - Serveur Arbitre")

        # Couleurs Among Us
        self.COLORS = {
            'red': (197, 17, 17),
            'blue': (19, 46, 210),
            'green': (17, 128, 45),
            'pink': (240, 89, 190),
            'orange': (239, 125, 13),
            'yellow': (245, 245, 87),
            'black': (63, 71, 78),
            'white': (214, 224, 240),
            'purple': (107, 47, 187),
            'brown': (113, 73, 30)
        }
        
        # Étoiles pour le fond
        self.stars = [(random.randint(0, self.WIDTH), 
                      random.randint(0, self.HEIGHT), 
                      random.random()*2) for _ in range(200)]
        
        # Polices
        self.font_title = pygame.font.Font(None, 48)
        self.font_normal = pygame.font.Font(None, 32)
        self.font_small = pygame.font.Font(None, 24)
        
        # Variables du jeu
        self.player_objects = {}
        self.animation_time = 0
        self.vote_animations = []
        self.message_queue = queue.Queue()
        self.console_messages = []
        self.max_console_lines = 15
        self.connected_players = {}
        self.current_round = 0
        self.spy = None
        self.votes = {}
        self.winner = None
        
        # Démarrage du serveur
        self.serveur = ServeurArbitre(broker_ip, nb_joueurs)
        self.serveur.afficher = self.custom_print
        self.server_thread = threading.Thread(target=self.serveur.demarrer_serveur)
        self.server_thread.daemon = True
        self.server_thread.start()

    def custom_print(self, message):
        """Fonction d'affichage personnalisée pour le serveur"""
        self.message_queue.put(message)
        print(message)  # Garde aussi l'affichage console

    def draw_space_background(self):
        """Dessine le fond spatial avec étoiles"""
        self.screen.fill((8, 8, 24))  # Bleu très foncé
        for x, y, size in self.stars:
            pygame.draw.circle(self.screen, (255, 255, 255), (int(x), int(y)), int(size))

    def create_player_positions(self):
        """Crée les positions des joueurs en cercle"""
        players = list(self.connected_players.keys())
        n = len(players)
        if n == 0:
            return

        radius = min(self.WIDTH, self.HEIGHT) * 0.25
        center_x = self.WIDTH * 0.5
        center_y = self.HEIGHT * 0.45

        self.player_objects.clear()
        for i, player_id in enumerate(players):
            angle = (2 * math.pi * i / n) - math.pi/2
            x = center_x + radius * math.cos(angle)
            y = center_y + radius * math.sin(angle)
            color = list(self.COLORS.values())[i % len(self.COLORS)]
            self.player_objects[player_id] = AmongUsPlayer(color, x, y)

    def draw_vote_info(self):
        """Affiche les informations de vote"""
        if not self.votes:
            return

        # Création d'un panneau d'information
        info_surface = pygame.Surface((300, self.HEIGHT), pygame.SRCALPHA)
        pygame.draw.rect(info_surface, (0, 0, 0, 128), (0, 0, 300, self.HEIGHT))
        
        y = 50
        title = self.font_title.render("Votes", True, (255, 255, 255))
        info_surface.blit(title, (20, y))
        y += 60

        for voter, voted_for in self.votes.items():
            if voter in self.player_objects and voted_for in self.player_objects:
                voter_color = self.player_objects[voter].color
                target_color = self.player_objects[voted_for].color
                
                # Nom du votant
                text = f"{voter} → {voted_for}"
                text_surface = self.font_normal.render(text, True, (255, 255, 255))
                
                # Indicateurs de couleur
                pygame.draw.circle(info_surface, voter_color, (30, y + 12), 10)
                pygame.draw.circle(info_surface, target_color, (160, y + 12), 10)
                
                info_surface.blit(text_surface, (50, y))
                y += 40

        self.screen.blit(info_surface, (self.WIDTH - 320, 0))

    def draw_game_status(self):
        """Affiche le statut du jeu"""
        status_text = [
            f"Round: {self.current_round}/{self.serveur.nb_rounds}",
            f"Joueurs: {len(self.connected_players)}/{self.serveur.nb_joueurs}",
            f"État: {'En cours' if self.serveur.jeu_actif else 'En attente'}"
        ]
        
        y = 20
        for text in status_text:
            surface = self.font_normal.render(text, True, (255, 255, 255))
            self.screen.blit(surface, (20, y))
            y += 40

    def update_game_state(self):
        """Met à jour l'état du jeu depuis le serveur"""
        self.connected_players = self.serveur.capteurs_connectes
        self.current_round = self.serveur.round_actuel
        self.spy = self.serveur.espion
        self.votes = self.serveur.votes_recus

    def run(self):
        """Boucle principale"""
        clock = pygame.time.Clock()
        
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

            # Mise à jour de l'état
            self.update_game_state()
            if not self.player_objects or len(self.player_objects) != len(self.connected_players):
                self.create_player_positions()

            # Animation
            self.animation_time += 0.05
            for player in self.player_objects.values():
                player.animation_offset = self.animation_time

            # Dessin
            self.draw_space_background()
            
            # Dessiner les joueurs
            for player_id, player in self.player_objects.items():
                is_spy = player_id == self.spy
                is_dead = False  # À implémenter selon la logique du jeu
                player.draw(self.screen, is_spy, is_dead)
                
                # Nom du joueur
                name_surface = self.font_small.render(str(player_id), True, (255, 255, 255))
                name_rect = name_surface.get_rect(center=(player.x, player.y + 50))
                self.screen.blit(name_surface, name_rect)

            # Dessiner les votes et le statut
            self.draw_vote_info()
            self.draw_game_status()

            pygame.display.flip()
            clock.tick(60)

if __name__ == "__main__":
    import random
    IP_BROKER = "10.109.150.194"
    display = ArbitreDisplay(IP_BROKER)
    display.run()