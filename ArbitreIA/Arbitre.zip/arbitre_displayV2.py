import pygame
import sys
from arbitreV5 import ServeurArbitre
import threading
import queue
from pygame import gfxdraw
import tkinter as tk
from tkinter import simpledialog
import math

class ArbitreDisplay:
    def __init__(self, broker_ip):
        # Demande du nombre de joueurs via une boîte de dialogue
        root = tk.Tk()
        root.withdraw()
        nb_joueurs = simpledialog.askinteger("Configuration", 
        "Nombre de joueurs (2-10):", 
        minvalue=2, 
        maxvalue=10)
        if nb_joueurs is None:
            sys.exit()

        pygame.init()
        
        # Dimensions de la fenêtre
        self.WIDTH = 1200
        self.HEIGHT = 800
        self.screen = pygame.display.set_mode((self.WIDTH, self.HEIGHT))
        pygame.display.set_caption("Serveur Arbitre IoT - Version 3D")
        
        # Couleurs avec transparence
        self.BLACK = (0, 0, 0)
        self.WHITE = (255, 255, 255)
        self.GRAY = (40, 40, 40)
        self.GREEN = (0, 255, 0)
        self.RED = (255, 0, 0)
        self.BLUE = (0, 120, 255)
        self.TRANSPARENT_BLUE = (0, 120, 255, 128)
        
        # Ajout de nouvelles couleurs
        self.WINNER_GOLD = (255, 215, 0)
        self.LOSER_RED = (139, 0, 0)
        self.VOTE_ARROW_COLOR = (0, 191, 255)
        
        # Polices
        self.font_title = pygame.font.Font(None, 40)
        self.font_normal = pygame.font.Font(None, 26)
        self.font_small = pygame.font.Font(None, 22)
        
        # Variables d'animation
        self.animation_offset = 0
        self.animation_speed = 0.5
        
        # Configuration des sections
        self.sections = {
            'game_info': {'x': 30, 'y': 30, 'w': 350, 'h': 150},
            'players': {'x': 30, 'y': 200, 'w': 350, 'h': 250},
            'votes': {'x': 30, 'y': 470, 'w': 350, 'h': 300},
            'console': {'x': 400, 'y': 30, 'w': 770, 'h': 740}
        }
        
        # Initialisation standard
        self.message_queue = queue.Queue()
        self.console_messages = []
        self.max_console_lines = 25
        self.connected_players = {}
        self.current_round = 0
        self.spy = None
        self.votes = {}
        self.temperatures = {}
        
        # Stockage des résultats de partie
        self.winner = None
        self.game_results = []  # Liste pour stocker l'historique des parties
        
        # Configuration des joueurs pour l'affichage en carré
        self.player_positions = {}  # Stockage des positions des joueurs
        self.player_radius = 40
        self.player_spacing = 100
        
        # Démarrage du serveur
        self.serveur = ServeurArbitre(broker_ip, nb_joueurs)
        self.serveur.afficher = self.custom_print
        self.server_thread = threading.Thread(target=self.serveur.demarrer_serveur)
        self.server_thread.daemon = True
        self.server_thread.start()

    def draw_rounded_rect(self, surface, rect, color, corner_radius):
        """Dessine un rectangle avec coins arrondis et effet 3D"""
        pygame.draw.rect(surface, color, rect, border_radius=corner_radius)
        # Effet de brillance
        highlight = (min(color[0] + 30, 255), 
                    min(color[1] + 30, 255), 
                    min(color[2] + 30, 255))
        pygame.draw.line(surface, highlight, 
                        (rect.left, rect.bottom), 
                        (rect.left, rect.top), 3)
        pygame.draw.line(surface, highlight, 
                        (rect.left, rect.top), 
                        (rect.right, rect.top), 3)

    def draw_section(self, title, x, y, width, height):
        """Dessine une section avec effets 3D"""
        # Fond avec effet de profondeur
        shadow_offset = 5
        pygame.draw.rect(self.screen, (20, 20, 20), 
                        (x + shadow_offset, y + shadow_offset, width, height))
        
        # Rectangle principal avec coins arrondis
        rect = pygame.Rect(x, y, width, height)
        self.draw_rounded_rect(self.screen, rect, self.GRAY, 10)
        
        # Titre avec effet
        title_shadow = self.font_title.render(title, True, (50, 50, 50))
        title_surface = self.font_title.render(title, True, self.BLUE)
        self.screen.blit(title_shadow, (x + 12, y - 28))
        self.screen.blit(title_surface, (x + 10, y - 30))

    def draw_vote_arrow(self, start_pos, end_pos):
        """Dessine une flèche de vote entre deux joueurs"""
        if start_pos and end_pos:
            # Calculer la direction
            dx = end_pos[0] - start_pos[0]
            dy = end_pos[1] - start_pos[1]
            length = math.sqrt(dx*dx + dy*dy)
            
            if length == 0:
                return
                
            # Normaliser et ajuster pour que la flèche ne touche pas les cercles
            dx, dy = dx/length, dy/length
            start = (start_pos[0] + dx * self.player_radius,
                    start_pos[1] + dy * self.player_radius)
            end = (end_pos[0] - dx * self.player_radius,
                   end_pos[1] - dy * self.player_radius)
            
            # Dessiner la ligne
            pygame.draw.line(self.screen, self.VOTE_ARROW_COLOR, start, end, 2)
            
            # Dessiner la pointe de la flèche
            arrow_size = 10
            angle = math.atan2(dy, dx)
            pygame.draw.polygon(self.screen, self.VOTE_ARROW_COLOR, [
                (end[0], end[1]),
                (end[0] - arrow_size * math.cos(angle - math.pi/6),
                 end[1] - arrow_size * math.sin(angle - math.pi/6)),
                (end[0] - arrow_size * math.cos(angle + math.pi/6),
                 end[1] - arrow_size * math.sin(angle + math.pi/6))
            ])

    def draw_players(self, x, y, width, height):
        """Dessine la section des joueurs avec leur disposition en carré"""
        self.draw_section("Joueurs", x, y, width, height)
        
        # Calculer les positions si nécessaire
        if not self.player_positions or len(self.player_positions) != len(self.connected_players):
            self.calculate_player_positions()
        
        # Dessiner les joueurs
        for player_id, pos in self.player_positions.items():
            self.draw_player_node(player_id, pos[0], pos[1])

    def draw_votes(self, x, y, width, height):
        """Dessine la section des votes avec des flèches"""
        self.draw_section("Votes", x, y, width, height)
        
        # Dessiner les flèches de vote
        for voter, voted_for in self.votes.items():
            if voter in self.player_positions and voted_for in self.player_positions:
                start_pos = self.player_positions[voter]
                end_pos = self.player_positions[voted_for]
                self.draw_vote_arrow(start_pos, end_pos)

    def draw_console(self, x, y, width, height):
        """Console avec effet de terminal"""
        self.draw_section("Console", x, y, width, height)
        
        console_surface = pygame.Surface((width - 20, height - 40))
        console_surface.fill((0, 0, 0))
        
        y_offset = 10
        for message in self.console_messages[-self.max_console_lines:]:
            color = self.WHITE
            if "ERREUR" in message:
                color = self.RED
            elif "OK" in message:
                color = self.GREEN
            
            text_surface = self.font_small.render(message, True, color)
            console_surface.blit(text_surface, (10, y_offset))
            y_offset += 25
        
        self.screen.blit(console_surface, (x + 10, y + 20))

    def custom_print(self, message):
        """Fonction d'affichage personnalisée pour le serveur"""
        self.message_queue.put(message)
        print(message)  # Garde aussi l'affichage console

    def calculate_player_positions(self):
        """Calcule les positions des joueurs en carré"""
        players = list(self.connected_players.keys())
        if not players:
            return

        n = len(players)
        cols = math.ceil(math.sqrt(n))
        rows = math.ceil(n / cols)
        
        start_x = self.sections['players']['x'] + self.sections['players']['w'] // 2 - (cols * self.player_spacing) // 2
        start_y = self.sections['players']['y'] + 60

        self.player_positions.clear()
        idx = 0
        for row in range(rows):
            for col in range(cols):
                if idx < n:
                    x = start_x + col * self.player_spacing
                    y = start_y + row * self.player_spacing
                    self.player_positions[players[idx]] = (x, y)
                    idx += 1

    def draw_player_node(self, player_id, x, y):
        """Dessine un joueur avec son statut"""
        # Cercle principal
        color = self.RED if player_id == self.spy else self.GREEN
        pygame.draw.circle(self.screen, color, (x, y), self.player_radius)
        
        # Bordure
        pygame.draw.circle(self.screen, self.WHITE, (x, y), self.player_radius, 2)
        
        # Nom du joueur
        text = self.font_small.render(str(player_id), True, self.WHITE)
        text_rect = text.get_rect(center=(x, y))
        self.screen.blit(text, text_rect)
        
        # Affichage du statut de gagnant/perdant si la partie est terminée
        if self.winner is not None:
            if (self.spy and self.winner == "espion" and player_id == self.spy) or \
               (not self.spy and self.winner == "capteurs" and player_id != self.spy):
                pygame.draw.circle(self.screen, self.WINNER_GOLD, (x, y), self.player_radius + 5, 3)
                crown = self.font_normal.render('👑', True, self.WINNER_GOLD)
                self.screen.blit(crown, (x - 10, y - self.player_radius - 20))

    def update_game_state(self):
        """Met à jour l'état du jeu depuis le serveur"""
        previous_round = self.current_round
        self.connected_players = self.serveur.capteurs_connectes
        self.current_round = self.serveur.round_actuel
        self.spy = self.serveur.espion
        self.votes = self.serveur.votes_recus
        self.temperatures = self.serveur.temperatures
        
        # Vérifier si une partie vient de se terminer
        if previous_round > 0 and self.current_round == 0:
            if hasattr(self.serveur, 'dernier_gagnant'):
                self.winner = self.serveur.dernier_gagnant
                self.game_results.append({
                    'winner': self.winner,
                    'spy': self.spy,
                    'votes': self.votes.copy()
                })
        elif self.current_round == 1:
            self.winner = None

    def draw_game_info(self, x, y, width, height):
        """Dessine les informations de la partie en cours"""
        self.draw_section("État du Jeu", x, y, width, height)
        
        y_offset = y + 20
        info_texts = [
            f"Round: {self.current_round}/{self.serveur.nb_rounds}",
            f"Joueurs: {len(self.connected_players)}/{self.serveur.nb_joueurs}",
            f"Partie active: {'Oui' if self.serveur.jeu_actif else 'Non'}"
        ]
        
        for text in info_texts:
            text_surface = self.font_normal.render(text, True, self.WHITE)
            self.screen.blit(text_surface, (x + 10, y_offset))
            y_offset += 30

    # ... Reste du code inchangé jusqu'à la méthode run() ...

    def run(self):
        """Boucle principale avec animations"""
        clock = pygame.time.Clock()
        
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

            # Mise à jour des animations
            self.animation_offset += self.animation_speed
            if self.animation_offset > 360:
                self.animation_offset = 0

            # Mises à jour standard
            while not self.message_queue.empty():
                message = self.message_queue.get()
                self.console_messages.append(message)
                if len(self.console_messages) > self.max_console_lines:
                    self.console_messages.pop(0)

            self.update_game_state()

            # Dessin avec effet de fond animé
            self.screen.fill(self.BLACK)
            
            # Effet de grille en arrière-plan
            for i in range(0, self.WIDTH, 30):
                alpha = abs(int(math.sin(i + self.animation_offset) * 50))
                pygame.draw.line(self.screen, (0, 50, 100, alpha), 
                               (i, 0), (i, self.HEIGHT), 1)
            
            # Dessin des sections
            for section in self.sections.values():
                if section == self.sections['votes']:
                    self.draw_votes(section['x'], section['y'], 
                                  section['w'], section['h'])
                elif section == self.sections['console']:
                    self.draw_console(section['x'], section['y'], 
                                    section['w'], section['h'])
                else:
                    self.draw_game_info(section['x'], section['y'], 
                                      section['w'], section['h'])

            pygame.display.flip()
            clock.tick(60)

if __name__ == "__main__":
    IP_BROKER = "10.109.150.194"
    display = ArbitreDisplay(IP_BROKER)
    display.run()